# I Am Rich 💎

This is a Flutter implementation of the famous "I Am Rich" app. The app displays a luxurious gem image and serves as a symbol of wealth and exclusivity.

## Screenshot 📸
![I Am Rich Screenshot](https://github.com/alihussainzada/flutter_subject_4Uni/blob/main/iAmRich/appImage.png)
